﻿namespace konkoor.Properties
{
    partial class safheasli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonsabt = new System.Windows.Forms.Button();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.email = new System.Windows.Forms.TextBox();
            this.codeposti = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tellsabet = new System.Windows.Forms.TextBox();
            this.tellhamrah = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.codeemtehani = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.codekarshenasi = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.jensiat = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.codeshenasname = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.shomareshenasname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.codemeli = new System.Windows.Forms.TextBox();
            this.nampedar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.namkhanevadegi = new System.Windows.Forms.TextBox();
            this.nam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.buttonsabt);
            this.panel1.Controls.Add(this.date);
            this.panel1.Controls.Add(this.email);
            this.panel1.Controls.Add(this.codeposti);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.tellsabet);
            this.panel1.Controls.Add(this.tellhamrah);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.codeemtehani);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.comboBox9);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.codekarshenasi);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.comboBox7);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.jensiat);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.codeshenasname);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.shomareshenasname);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.codemeli);
            this.panel1.Controls.Add(this.nampedar);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.namkhanevadegi);
            this.panel1.Controls.Add(this.nam);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(145, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 501);
            this.panel1.TabIndex = 0;
            // 
            // buttonsabt
            // 
            this.buttonsabt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsabt.Location = new System.Drawing.Point(300, 459);
            this.buttonsabt.Name = "buttonsabt";
            this.buttonsabt.Size = new System.Drawing.Size(128, 39);
            this.buttonsabt.TabIndex = 38;
            this.buttonsabt.Text = "sabtnam";
            this.buttonsabt.UseVisualStyleBackColor = true;
            this.buttonsabt.Click += new System.EventHandler(this.buttonsabt_Click);
            // 
            // date
            // 
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(406, 222);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(288, 27);
            this.date.TabIndex = 37;
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(411, 400);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(167, 22);
            this.email.TabIndex = 35;
            this.email.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // codeposti
            // 
            this.codeposti.Location = new System.Drawing.Point(123, 400);
            this.codeposti.Name = "codeposti";
            this.codeposti.Size = new System.Drawing.Size(167, 22);
            this.codeposti.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(351, 400);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 20);
            this.label17.TabIndex = 33;
            this.label17.Text = "email:";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(26, 398);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 20);
            this.label16.TabIndex = 32;
            this.label16.Text = "code posti:";
            // 
            // tellsabet
            // 
            this.tellsabet.Location = new System.Drawing.Point(517, 359);
            this.tellsabet.Name = "tellsabet";
            this.tellsabet.Size = new System.Drawing.Size(167, 22);
            this.tellsabet.TabIndex = 31;
            // 
            // tellhamrah
            // 
            this.tellhamrah.Location = new System.Drawing.Point(179, 357);
            this.tellhamrah.Name = "tellhamrah";
            this.tellhamrah.Size = new System.Drawing.Size(167, 22);
            this.tellhamrah.TabIndex = 30;
            this.tellhamrah.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(366, 359);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 20);
            this.label15.TabIndex = 29;
            this.label15.Text = "telephone sabet:";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(26, 357);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(147, 20);
            this.label14.TabIndex = 28;
            this.label14.Text = "telephone hamrah:";
            // 
            // codeemtehani
            // 
            this.codeemtehani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codeemtehani.FormattingEnabled = true;
            this.codeemtehani.Items.AddRange(new object[] {
            "1000",
            "2000",
            "3000",
            "4000",
            "5000"});
            this.codeemtehani.Location = new System.Drawing.Point(621, 314);
            this.codeemtehani.Name = "codeemtehani";
            this.codeemtehani.Size = new System.Drawing.Size(121, 28);
            this.codeemtehani.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(427, 317);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(179, 20);
            this.label13.TabIndex = 26;
            this.label13.Text = "code reshte emtehanii:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "computer : 1000",
            "bargh : 2000",
            "mekanik : 3000",
            "omran : 4000",
            "sanaye : 5000"});
            this.comboBox9.Location = new System.Drawing.Point(283, 317);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(121, 28);
            this.comboBox9.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 317);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(250, 20);
            this.label12.TabIndex = 24;
            this.label12.Text = " rahnama code reshte emtehani:";
            // 
            // codekarshenasi
            // 
            this.codekarshenasi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codekarshenasi.FormattingEnabled = true;
            this.codekarshenasi.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.codekarshenasi.Location = new System.Drawing.Point(621, 269);
            this.codekarshenasi.Name = "codekarshenasi";
            this.codekarshenasi.Size = new System.Drawing.Size(121, 28);
            this.codekarshenasi.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(427, 272);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(188, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "code reshte karshenasi:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // comboBox7
            // 
            this.comboBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "computer : 1",
            "bargh : 2",
            "mekanik : 3",
            "omran : 4",
            "sanaye : 5"});
            this.comboBox7.Location = new System.Drawing.Point(283, 269);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 28);
            this.comboBox7.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 277);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(263, 20);
            this.label10.TabIndex = 20;
            this.label10.Text = " rahnama code reshte karshenasi:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(292, 224);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "tarikh tavalod:";
            // 
            // jensiat
            // 
            this.jensiat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jensiat.FormattingEnabled = true;
            this.jensiat.Items.AddRange(new object[] {
            "zan",
            "mard"});
            this.jensiat.Location = new System.Drawing.Point(112, 224);
            this.jensiat.Name = "jensiat";
            this.jensiat.Size = new System.Drawing.Size(121, 28);
            this.jensiat.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "jensiat:";
            // 
            // codeshenasname
            // 
            this.codeshenasname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codeshenasname.FormattingEnabled = true;
            this.codeshenasname.Items.AddRange(new object[] {
            "111",
            "222",
            "333",
            "444",
            "555"});
            this.codeshenasname.Location = new System.Drawing.Point(639, 172);
            this.codeshenasname.Name = "codeshenasname";
            this.codeshenasname.Size = new System.Drawing.Size(121, 28);
            this.codeshenasname.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(427, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(206, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "code sodoor shenasname:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "tehran : 111",
            "esfahan : 222",
            "guilan : 333",
            "mazandaran : 444",
            "shiraz : 555"});
            this.comboBox1.Location = new System.Drawing.Point(300, 172);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(281, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = " rahnama code sodoor shenasname:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // shomareshenasname
            // 
            this.shomareshenasname.Location = new System.Drawing.Point(237, 135);
            this.shomareshenasname.Name = "shomareshenasname";
            this.shomareshenasname.Size = new System.Drawing.Size(261, 22);
            this.shomareshenasname.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(179, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "shomare shenasname:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // codemeli
            // 
            this.codemeli.Location = new System.Drawing.Point(411, 82);
            this.codemeli.Name = "codemeli";
            this.codemeli.Size = new System.Drawing.Size(261, 22);
            this.codemeli.TabIndex = 7;
            // 
            // nampedar
            // 
            this.nampedar.Location = new System.Drawing.Point(128, 84);
            this.nampedar.Name = "nampedar";
            this.nampedar.Size = new System.Drawing.Size(167, 22);
            this.nampedar.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(315, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "code meli:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "nam pedar:";
            // 
            // namkhanevadegi
            // 
            this.namkhanevadegi.Location = new System.Drawing.Point(469, 21);
            this.namkhanevadegi.Name = "namkhanevadegi";
            this.namkhanevadegi.Size = new System.Drawing.Size(203, 22);
            this.namkhanevadegi.TabIndex = 3;
            // 
            // nam
            // 
            this.nam.Location = new System.Drawing.Point(92, 21);
            this.nam.Name = "nam";
            this.nam.Size = new System.Drawing.Size(203, 22);
            this.nam.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(315, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "namkhanevadegi:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "nam:";
            // 
            // safheasli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 554);
            this.Controls.Add(this.panel1);
            this.Name = "safheasli";
            this.Text = "safheasli";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox codemeli;
        private System.Windows.Forms.TextBox nampedar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox namkhanevadegi;
        private System.Windows.Forms.TextBox nam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox shomareshenasname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox codeshenasname;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox jensiat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox codekarshenasi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox codeemtehani;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.TextBox tellsabet;
        private System.Windows.Forms.TextBox tellhamrah;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox codeposti;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Button buttonsabt;
    }
}